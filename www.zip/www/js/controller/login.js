app.controller('loginCtrl', function($scope, $http, $ionicPopup, $state, $ionicHistory) {

});