app.controller('homeCtrl', function($scope, $http, $ionicPopup, $state, $ionicHistory) {

});