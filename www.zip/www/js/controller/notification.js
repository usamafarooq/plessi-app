app.controller('notificationCtrl', function($scope, $http, $ionicPopup, $state, $ionicHistory) {

});