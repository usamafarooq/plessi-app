app.controller('listCtrl', function($scope, $http, $ionicPopup, $state, $ionicHistory) {

});