app.controller('accountCtrl', function($scope, $http, $ionicPopup, $state, $ionicHistory) {

});